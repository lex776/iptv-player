#!/usr/bin/env python3
"""Patches the freshly generated android/ folder:
1. Replaces AndroidManifest.xml with a TV-ready version (INTERNET permission,
   LEANBACK launcher, cleartext traffic for http:// streams).
2. Replaces MainActivity with a version exposing Android TV detection
   via MethodChannel 'iptv_player/platform'.
Run from the project root AFTER `flutter create` generated android/.
"""
import glob
import os
import re
import sys

MANIFEST = '''<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Network -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />

    <!-- Storage (for local M3U files) -->
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"
        android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />

    <!-- TV features: touchscreen not required, leanback optional -->
    <uses-feature android:name="android.hardware.touchscreen" android:required="false" />
    <uses-feature android:name="android.software.leanback" android:required="false" />

    <application
        android:label="IPTV Player"
        android:name="${applicationName}"
        android:icon="@mipmap/ic_launcher"
        android:banner="@mipmap/ic_launcher"
        android:usesCleartextTraffic="true"
        android:hardwareAccelerated="true">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:taskAffinity=""
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <meta-data
                android:name="io.flutter.embedding.android.NormalTheme"
                android:resource="@style/NormalTheme" />

            <!-- Mobile launcher -->
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>

            <!-- Android TV / Fire Stick launcher -->
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LEANBACK_LAUNCHER"/>
            </intent-filter>
        </activity>

        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>

    <queries>
        <intent>
            <action android:name="android.intent.action.PROCESS_TEXT"/>
            <data android:mimeType="text/plain"/>
        </intent>
    </queries>
</manifest>
'''

MAIN_ACTIVITY_BODY = '''
import android.content.pm.PackageManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "iptv_player/platform"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method == "isAndroidTV") {
                    val pm = applicationContext.packageManager
                    result.success(pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK))
                } else {
                    result.notImplemented()
                }
            }
    }
}
'''


def patch_manifest() -> None:
    path = os.path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml')
    if not os.path.exists(path):
        sys.exit(f'ERROR: {path} not found. Run flutter create first.')
    with open(path, 'w', encoding='utf-8') as f:
        f.write(MANIFEST)
    print(f'[OK] Manifest patched: {path}')


def patch_main_activity() -> None:
    candidates = glob.glob(
        'android/app/src/main/kotlin/**/MainActivity.kt', recursive=True)
    if not candidates:
        candidates = glob.glob(
            'android/app/src/main/java/**/MainActivity.kt', recursive=True)
    if not candidates:
        sys.exit('ERROR: MainActivity.kt not found.')
    path = candidates[0]
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()
    m = re.search(r'^package\s+[\w.]+', content, re.MULTILINE)
    if not m:
        sys.exit(f'ERROR: package declaration not found in {path}')
    package_line = m.group(0)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(package_line + '\n' + MAIN_ACTIVITY_BODY)
    print(f'[OK] MainActivity patched: {path} ({package_line})')


if __name__ == '__main__':
    patch_manifest()
    patch_main_activity()
    print('[DONE] Android platform patched for TV + IPTV streaming.')
