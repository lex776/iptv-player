import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:media_kit/media_kit.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'models/channel.dart';
import 'models/playlist.dart';
import 'models/epg_program.dart';
import 'providers/playlist_provider.dart';
import 'providers/player_provider.dart';
import 'providers/epg_provider.dart';
import 'services/storage_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize MediaKit (video player)
  MediaKit.ensureInitialized();

  // Initialize Hive
  await Hive.initFlutter();
  Hive.registerAdapter(ChannelAdapter());
  Hive.registerAdapter(PlaylistAdapter());
  Hive.registerAdapter(EpgProgramAdapter());

  // Open Hive boxes
  await Hive.openBox<Playlist>('playlists');
  await Hive.openBox<Channel>('favorites');
  await Hive.openBox('settings');

  // System UI: full immersive for TV
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
    DeviceOrientation.portraitUp,
  ]);

  final storageService = StorageService();
  await storageService.init();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => PlaylistProvider(storageService: storageService),
        ),
        ChangeNotifierProvider(
          create: (_) => PlayerProvider(),
        ),
        ChangeNotifierProvider(
          create: (_) => EpgProvider(),
        ),
      ],
      child: const IPTVPlayerApp(),
    ),
  );
}
