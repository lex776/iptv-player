import 'package:hive/hive.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/channel.dart';
import '../models/playlist.dart';

class StorageService {
  late SharedPreferences _prefs;
  late Box<Playlist> _playlistsBox;
  late Box<Channel> _favoritesBox;
  late Box _settingsBox;

  bool _ready = false;
  bool get isReady => _ready;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _playlistsBox = Hive.box<Playlist>('playlists');
    _favoritesBox = Hive.box<Channel>('favorites');
    _settingsBox = Hive.box('settings');
    _ready = true;
  }

  // -- Playlists ---------------------------------------------------------------

  List<Playlist> getAllPlaylists() => _playlistsBox.values.toList()
    ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

  Future<void> savePlaylist(Playlist playlist) async {
    await _playlistsBox.put(playlist.id, playlist);
  }

  Future<void> deletePlaylist(String id) async {
    await _playlistsBox.delete(id);
  }

  Playlist? getPlaylist(String id) => _playlistsBox.get(id);

  Future<void> updatePlaylistRefreshTime(String id) async {
    final p = _playlistsBox.get(id);
    if (p != null) {
      p.lastRefreshed = DateTime.now();
      await _playlistsBox.put(id, p);
    }
  }

  Future<void> updatePlaylistChannelCount(String id, int count) async {
    final p = _playlistsBox.get(id);
    if (p != null) {
      p.channelCount = count;
      await _playlistsBox.put(id, p);
    }
  }

  Future<void> updatePlaylistEpgUrl(String id, String epgUrl) async {
    final p = _playlistsBox.get(id);
    if (p != null) {
      p.epgUrl = epgUrl;
      await _playlistsBox.put(id, p);
    }
  }

  // -- Favorites ----------------------------------------------------------------

  List<Channel> getFavorites() {
    return _favoritesBox.values.toList()
      ..sort((a, b) => a.name.compareTo(b.name));
  }

  bool isFavorite(String channelId) => _favoritesBox.containsKey(channelId);

  Future<void> addFavorite(Channel channel) async {
    await _favoritesBox.put(channel.id, channel.copyWith(isFavorite: true));
  }

  Future<void> removeFavorite(String channelId) async {
    await _favoritesBox.delete(channelId);
  }

  Future<bool> toggleFavorite(Channel channel) async {
    if (isFavorite(channel.id)) {
      await removeFavorite(channel.id);
      return false;
    } else {
      await addFavorite(channel);
      return true;
    }
  }

  // -- Recently Watched -----------------------------------------------------------

  static const _recentKey = 'recently_watched_ids';
  static const _maxRecent = 30;

  List<String> getRecentlyWatchedIds() {
    return _prefs.getStringList(_recentKey) ?? [];
  }

  Future<void> addToRecentlyWatched(String channelId) async {
    final list = getRecentlyWatchedIds();
    list.remove(channelId); // Remove duplicate
    list.insert(0, channelId); // Add to front
    if (list.length > _maxRecent) list.removeRange(_maxRecent, list.length);
    await _prefs.setStringList(_recentKey, list);
  }

  Future<void> clearRecentlyWatched() async {
    await _prefs.remove(_recentKey);
  }

  // -- Settings ---------------------------------------------------------------------

  static const _kTvMode = 'tv_mode_override';
  static const _kAutoPlay = 'auto_play';
  static const _kLastPlaylist = 'last_playlist_id';
  static const _kAspectRatio = 'aspect_ratio';
  static const _kEpgEnabled = 'epg_enabled';

  bool get tvModeOverride =>
      _settingsBox.get(_kTvMode, defaultValue: false) as bool;
  set tvModeOverride(bool v) => _settingsBox.put(_kTvMode, v);

  bool get autoPlay => _settingsBox.get(_kAutoPlay, defaultValue: true) as bool;
  set autoPlay(bool v) => _settingsBox.put(_kAutoPlay, v);

  String? get lastPlaylistId => _settingsBox.get(_kLastPlaylist) as String?;
  set lastPlaylistId(String? v) => _settingsBox.put(_kLastPlaylist, v);

  String get aspectRatio =>
      _settingsBox.get(_kAspectRatio, defaultValue: 'fit') as String;
  set aspectRatio(String v) => _settingsBox.put(_kAspectRatio, v);

  bool get epgEnabled =>
      _settingsBox.get(_kEpgEnabled, defaultValue: true) as bool;
  set epgEnabled(bool v) => _settingsBox.put(_kEpgEnabled, v);

  Future<void> clearAll() async {
    await _playlistsBox.clear();
    await _favoritesBox.clear();
    await _settingsBox.clear();
    await _prefs.clear();
  }
}
