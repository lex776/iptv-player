import 'package:collection/collection.dart';
import 'package:dio/dio.dart';
import 'package:xml/xml.dart';
import '../models/epg_program.dart';

class EpgParseResult {
  final Map<String, List<EpgProgram>> programs; // channelId -> programs
  final String? error;

  const EpgParseResult({required this.programs, this.error});
}

class EpgParser {
  final Dio _dio;

  EpgParser()
      : _dio = Dio(
          BaseOptions(
            connectTimeout: const Duration(seconds: 30),
            receiveTimeout: const Duration(minutes: 5),
            headers: {'User-Agent': 'IPTVPlayer/1.0 (Android)'},
          ),
        );

  Future<EpgParseResult> parseFromUrl(String url) async {
    try {
      final response = await _dio.get<String>(
        url,
        options: Options(
          responseType: ResponseType.plain,
          receiveTimeout: const Duration(minutes: 5),
        ),
      );

      if (response.statusCode != 200 || response.data == null) {
        return EpgParseResult(
          programs: {},
          error: 'EPG HTTP error: ${response.statusCode}',
        );
      }

      return _parseXmltvContent(response.data!);
    } on DioException catch (e) {
      return EpgParseResult(
        programs: {},
        error: 'EPG network error: ${e.message}',
      );
    } catch (e) {
      return EpgParseResult(
        programs: {},
        error: 'EPG parse error: $e',
      );
    }
  }

  // -- XMLTV parser ------------------------------------------------------------

  EpgParseResult _parseXmltvContent(String xmlContent) {
    try {
      final document = XmlDocument.parse(xmlContent);
      final programs = <String, List<EpgProgram>>{};

      // A cutoff: skip programs that ended more than 12 hours ago
      final cutoff = DateTime.now().subtract(const Duration(hours: 12));

      for (final prog in document.findAllElements('programme')) {
        try {
          final channelId = prog.getAttribute('channel');
          if (channelId == null || channelId.isEmpty) continue;

          final startStr = prog.getAttribute('start');
          final stopStr = prog.getAttribute('stop');
          if (startStr == null || stopStr == null) continue;

          final start = _parseXmltvDateTime(startStr);
          final stop = _parseXmltvDateTime(stopStr);
          if (start == null || stop == null) continue;
          if (stop.isBefore(cutoff)) continue;

          // Title (may have multiple lang variants - take first)
          final titleEl = prog.findElements('title').firstOrNull;
          final title = titleEl?.innerText.trim() ?? '';
          if (title.isEmpty) continue;

          final desc = prog.findElements('desc').firstOrNull?.innerText.trim();
          final category =
              prog.findElements('category').firstOrNull?.innerText.trim();
          final iconSrc =
              prog.findElements('icon').firstOrNull?.getAttribute('src');
          final rating = prog
              .findElements('rating')
              .firstOrNull
              ?.findElements('value')
              .firstOrNull
              ?.innerText
              .trim();

          final program = EpgProgram(
            channelId: channelId,
            title: title,
            description: desc?.isNotEmpty == true ? desc : null,
            start: start,
            stop: stop,
            category: category?.isNotEmpty == true ? category : null,
            icon: iconSrc?.isNotEmpty == true ? iconSrc : null,
            rating: rating?.isNotEmpty == true ? rating : null,
          );

          programs.putIfAbsent(channelId, () => []).add(program);
        } catch (_) {
          // Skip malformed entries silently
        }
      }

      // Sort each channel's list by start time
      for (final list in programs.values) {
        list.sort((a, b) => a.start.compareTo(b.start));
      }

      return EpgParseResult(programs: programs);
    } on XmlParserException catch (e) {
      return EpgParseResult(
        programs: {},
        error: 'Invalid XML: ${e.message}',
      );
    } catch (e) {
      return EpgParseResult(
        programs: {},
        error: 'XML processing error: $e',
      );
    }
  }

  // -- Date parser --------------------------------------------------------------

  /// Parses XMLTV datetime: `YYYYMMDDHHmmss +ZZZZ`
  DateTime? _parseXmltvDateTime(String raw) {
    try {
      final parts = raw.trim().split(RegExp(r'\s+'));
      if (parts.isEmpty) return null;

      final d = parts[0];
      if (d.length < 14) return null;

      final year = int.parse(d.substring(0, 4));
      final month = int.parse(d.substring(4, 6));
      final day = int.parse(d.substring(6, 8));
      final hour = int.parse(d.substring(8, 10));
      final minute = int.parse(d.substring(10, 12));
      final second = int.parse(d.substring(12, 14));

      var dt = DateTime(year, month, day, hour, minute, second);

      // Apply timezone offset -> convert to local time
      if (parts.length > 1) {
        final tz = parts[1];
        if (tz.length == 5) {
          final sign = tz[0] == '-' ? -1 : 1;
          final tzH = int.parse(tz.substring(1, 3));
          final tzM = int.parse(tz.substring(3, 5));
          final offset = Duration(hours: tzH, minutes: tzM) * sign;
          dt = dt.subtract(offset); // now UTC
          dt = DateTime.utc(dt.year, dt.month, dt.day, dt.hour, dt.minute,
                  dt.second)
              .toLocal();
        }
      }

      return dt;
    } catch (_) {
      return null;
    }
  }
}
