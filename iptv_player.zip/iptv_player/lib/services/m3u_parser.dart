import 'dart:io';
import 'package:dio/dio.dart';
import 'package:uuid/uuid.dart';
import '../models/channel.dart';

class M3uParseResult {
  final List<Channel> channels;
  final String? epgUrl;
  final String? error;

  const M3uParseResult({
    required this.channels,
    this.epgUrl,
    this.error,
  });
}

class M3uParser {
  final Dio _dio;
  static const _uuid = Uuid();

  M3uParser()
      : _dio = Dio(
          BaseOptions(
            connectTimeout: const Duration(seconds: 30),
            receiveTimeout: const Duration(seconds: 120),
            headers: {
              'User-Agent': 'IPTVPlayer/1.0 (Android)',
              'Accept': '*/*',
            },
          ),
        );

  /// Parse M3U from a remote URL
  Future<M3uParseResult> parseFromUrl(String url) async {
    try {
      final response = await _dio.get<String>(
        url,
        options: Options(
          responseType: ResponseType.plain,
          followRedirects: true,
          maxRedirects: 5,
        ),
      );

      if (response.statusCode != 200 || response.data == null) {
        return M3uParseResult(
          channels: [],
          error: 'Server returned HTTP ${response.statusCode}',
        );
      }

      return _parseContent(response.data!);
    } on DioException catch (e) {
      final msg = switch (e.type) {
        DioExceptionType.connectionTimeout => 'Connection timed out',
        DioExceptionType.receiveTimeout => 'Download timed out',
        DioExceptionType.badResponse =>
          'Server error: ${e.response?.statusCode}',
        DioExceptionType.connectionError => 'No internet connection',
        _ => 'Network error: ${e.message}',
      };
      return M3uParseResult(channels: [], error: msg);
    } catch (e) {
      return M3uParseResult(channels: [], error: 'Unexpected error: $e');
    }
  }

  /// Parse M3U from a local file path
  Future<M3uParseResult> parseFromFile(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) {
        return M3uParseResult(
          channels: [],
          error: 'File not found: $filePath',
        );
      }
      final content = await file.readAsString();
      return _parseContent(content);
    } catch (e) {
      return M3uParseResult(channels: [], error: 'File read error: $e');
    }
  }

  // -- Core parser -----------------------------------------------------------

  M3uParseResult _parseContent(String content) {
    // Normalize line endings
    final lines = content
        .replaceAll('\r\n', '\n')
        .replaceAll('\r', '\n')
        .split('\n')
        .map((l) => l.trim())
        .toList();

    if (lines.isEmpty) {
      return const M3uParseResult(channels: [], error: 'Empty file');
    }

    final firstLine = lines.first;
    if (!firstLine.startsWith('#EXTM3U')) {
      // Attempt simple URL-per-line fallback
      return _parseSimple(lines);
    }

    return _parseExtended(lines, firstLine);
  }

  M3uParseResult _parseSimple(List<String> lines) {
    final channels = <Channel>[];
    int idx = 0;
    for (final line in lines) {
      if (line.isEmpty || line.startsWith('#')) continue;
      if (_looksLikeUrl(line)) {
        channels.add(Channel(
          id: _uuid.v4(),
          name: 'Channel ${++idx}',
          url: line,
          groupTitle: 'Other',
        ));
      }
    }
    return M3uParseResult(channels: channels);
  }

  M3uParseResult _parseExtended(List<String> lines, String headerLine) {
    final channels = <Channel>[];

    // Extract global EPG URL from header
    final epgUrl = _attr(headerLine, 'url-tvg') ??
        _attr(headerLine, 'x-tvg-url') ??
        _attr(headerLine, 'tvg-url');

    String? pendingExtinf;
    String? pendingExtgrp;

    for (int i = 1; i < lines.length; i++) {
      final line = lines[i];
      if (line.isEmpty) continue;

      if (line.startsWith('#EXTINF:')) {
        pendingExtinf = line;
        continue;
      }

      if (line.startsWith('#EXTGRP:')) {
        pendingExtgrp = line.substring(8).trim();
        continue;
      }

      // Skip other directives
      if (line.startsWith('#')) continue;

      // Stream URL line
      if (_looksLikeUrl(line)) {
        if (pendingExtinf != null) {
          final ch = _buildChannel(pendingExtinf, line, pendingExtgrp);
          if (ch != null) channels.add(ch);
        } else {
          channels.add(Channel(
            id: _uuid.v4(),
            name: _nameFromUrl(line),
            url: line,
            groupTitle: pendingExtgrp ?? 'Other',
          ));
        }
        pendingExtinf = null;
        pendingExtgrp = null;
      }
    }

    return M3uParseResult(channels: channels, epgUrl: epgUrl);
  }

  Channel? _buildChannel(String extinf, String url, String? fallbackGroup) {
    try {
      // #EXTINF:-1 key="val" key="val",Channel Display Name
      final commaIdx = extinf.lastIndexOf(',');
      if (commaIdx == -1) return null;

      final attrPart = extinf.substring(0, commaIdx);
      String displayName = extinf.substring(commaIdx + 1).trim();
      if (displayName.isEmpty) displayName = 'Unknown';

      final tvgId = _attr(attrPart, 'tvg-id');
      final tvgName = _attr(attrPart, 'tvg-name');
      final tvgLogo = _attr(attrPart, 'tvg-logo');
      final groupTitle =
          _attr(attrPart, 'group-title') ?? fallbackGroup ?? 'Other';
      final language = _attr(attrPart, 'tvg-language');
      final country = _attr(attrPart, 'tvg-country');

      return Channel(
        id: _uuid.v4(),
        name: displayName,
        url: url.trim(),
        logoUrl: (tvgLogo != null && tvgLogo.isNotEmpty) ? tvgLogo : null,
        groupTitle: groupTitle.isNotEmpty ? groupTitle : 'Other',
        tvgId: tvgId?.isNotEmpty == true ? tvgId : null,
        tvgName: tvgName?.isNotEmpty == true ? tvgName : null,
        language: language?.isNotEmpty == true ? language : null,
        country: country?.isNotEmpty == true ? country : null,
      );
    } catch (_) {
      return null;
    }
  }

  // -- Helpers ----------------------------------------------------------------

  /// Extract attribute value - supports both double and single quotes
  String? _attr(String text, String key) {
    for (final pattern in [
      RegExp('$key="([^"]*)"'),
      RegExp("$key='([^']*)'"),
    ]) {
      final m = pattern.firstMatch(text);
      if (m != null) {
        final v = m.group(1)?.trim();
        return (v != null && v.isNotEmpty) ? v : null;
      }
    }
    return null;
  }

  bool _looksLikeUrl(String s) {
    final lower = s.toLowerCase();
    return lower.startsWith('http://') ||
        lower.startsWith('https://') ||
        lower.startsWith('rtsp://') ||
        lower.startsWith('rtmp://') ||
        lower.startsWith('rtsps://') ||
        lower.startsWith('udp://') ||
        lower.startsWith('rtp://');
  }

  String _nameFromUrl(String url) {
    try {
      final segs = Uri.parse(url).pathSegments;
      final last = segs.lastWhere((s) => s.isNotEmpty, orElse: () => '');
      final cleaned = last.replaceAll(RegExp(r'\.(m3u8?|ts|mp4)$'), '');
      return cleaned.isNotEmpty ? cleaned : Uri.parse(url).host;
    } catch (_) {
      return 'Unknown';
    }
  }
}
