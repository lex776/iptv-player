import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import '../models/channel.dart';

enum PlayerStatus { idle, loading, playing, paused, buffering, error }

enum AspectRatioMode {
  fit('Fit', -1),
  fill('Fill', -2),
  sixteenNine('16:9', 16 / 9),
  fourThree('4:3', 4 / 3),
  oneOne('1:1', 1.0),
  twoOne('2.35:1', 2.35);

  const AspectRatioMode(this.label, this.ratio);
  final String label;
  final double ratio;
}

class PlayerProvider extends ChangeNotifier {
  late final Player _player;
  late final VideoController _controller;

  // -- State ------------------------------------------------------------------

  Channel? _currentChannel;
  int _currentChannelIndex = 0;
  List<Channel> _channelList = [];

  PlayerStatus _status = PlayerStatus.idle;
  String? _errorMessage;

  AspectRatioMode _aspectRatioMode = AspectRatioMode.fit;
  bool _controlsVisible = true;
  bool _channelListVisible = false;
  double _volume = 1.0;
  bool _muted = false;

  Timer? _controlsTimer;

  // -- Constructor ------------------------------------------------------------------

  PlayerProvider() {
    _player = Player(
      configuration: const PlayerConfiguration(
        title: 'IPTV Player',
        logLevel: MPVLogLevel.error,
        bufferSize: 32 * 1024 * 1024, // 32 MB buffer
      ),
    );
    _controller = VideoController(_player);
    _listenToPlayer();
  }

  // -- Getters ------------------------------------------------------------------

  Player get player => _player;
  VideoController get controller => _controller;
  Channel? get currentChannel => _currentChannel;
  int get currentChannelIndex => _currentChannelIndex;
  List<Channel> get channelList => List.unmodifiable(_channelList);
  PlayerStatus get status => _status;
  String? get errorMessage => _errorMessage;
  AspectRatioMode get aspectRatioMode => _aspectRatioMode;
  bool get controlsVisible => _controlsVisible;
  bool get channelListVisible => _channelListVisible;
  double get volume => _volume;
  bool get muted => _muted;
  bool get isPlaying => _status == PlayerStatus.playing;
  bool get isBuffering => _status == PlayerStatus.buffering;
  bool get hasError => _status == PlayerStatus.error;
  bool get hasChannel => _currentChannel != null;
  bool get hasNext => _currentChannelIndex < _channelList.length - 1;
  bool get hasPrevious => _currentChannelIndex > 0;

  // -- Playback ------------------------------------------------------------------

  Future<void> playChannel(
      Channel channel, int index, List<Channel> list) async {
    _currentChannel = channel;
    _currentChannelIndex = index;
    _channelList = list;
    _status = PlayerStatus.loading;
    _errorMessage = null;
    notifyListeners();

    try {
      await _player.open(Media(channel.url), play: true);
      _showControlsTemporarily();
    } catch (e) {
      _status = PlayerStatus.error;
      _errorMessage = 'Cannot open stream: ${channel.url}';
      notifyListeners();
    }
  }

  Future<void> playNext() async {
    if (!hasNext) return;
    final next = _channelList[_currentChannelIndex + 1];
    await playChannel(next, _currentChannelIndex + 1, _channelList);
  }

  Future<void> playPrevious() async {
    if (!hasPrevious) return;
    final prev = _channelList[_currentChannelIndex - 1];
    await playChannel(prev, _currentChannelIndex - 1, _channelList);
  }

  Future<void> togglePlayPause() async {
    await _player.playOrPause();
    _showControlsTemporarily();
  }

  Future<void> stop() async {
    _controlsTimer?.cancel();
    await _player.stop();
    _status = PlayerStatus.idle;
    _currentChannel = null;
    notifyListeners();
  }

  // -- Aspect ratio ------------------------------------------------------------------

  void cycleAspectRatio() {
    final modes = AspectRatioMode.values;
    final next = (modes.indexOf(_aspectRatioMode) + 1) % modes.length;
    _aspectRatioMode = modes[next];
    notifyListeners();
  }

  void setAspectRatio(AspectRatioMode mode) {
    _aspectRatioMode = mode;
    notifyListeners();
  }

  // -- Controls visibility ------------------------------------------------------------------

  void showControls({bool autoHide = true}) {
    _controlsVisible = true;
    notifyListeners();
    if (autoHide) _scheduleHideControls();
  }

  void hideControls() {
    _controlsTimer?.cancel();
    _controlsVisible = false;
    notifyListeners();
  }

  void toggleControls() {
    if (_controlsVisible) {
      hideControls();
    } else {
      showControls();
    }
  }

  void _showControlsTemporarily() => showControls(autoHide: true);

  void _scheduleHideControls() {
    _controlsTimer?.cancel();
    _controlsTimer = Timer(const Duration(seconds: 5), () {
      if (_status == PlayerStatus.playing) hideControls();
    });
  }

  // -- Channel list panel ------------------------------------------------------------------

  void toggleChannelList() {
    _channelListVisible = !_channelListVisible;
    if (_channelListVisible) {
      _controlsTimer?.cancel(); // Keep controls visible
      _controlsVisible = true;
    }
    notifyListeners();
  }

  void hideChannelList() {
    _channelListVisible = false;
    notifyListeners();
  }

  // -- Volume ------------------------------------------------------------------

  Future<void> setVolume(double v) async {
    _volume = v.clamp(0.0, 1.0);
    _muted = false;
    await _player.setVolume(_volume * 100);
    notifyListeners();
  }

  Future<void> toggleMute() async {
    _muted = !_muted;
    await _player.setVolume(_muted ? 0 : _volume * 100);
    notifyListeners();
  }

  // -- Player stream listeners ------------------------------------------------------------------

  void _listenToPlayer() {
    _player.stream.playing.listen((playing) {
      if (_status == PlayerStatus.loading ||
          _status == PlayerStatus.buffering) {
        return;
      }
      _status = playing ? PlayerStatus.playing : PlayerStatus.paused;
      notifyListeners();
    });

    _player.stream.buffering.listen((buffering) {
      if (buffering) {
        _status = PlayerStatus.buffering;
      } else {
        _status =
            _player.state.playing ? PlayerStatus.playing : PlayerStatus.paused;
      }
      notifyListeners();
    });

    _player.stream.error.listen((error) {
      if (error.isNotEmpty && _currentChannel != null) {
        _status = PlayerStatus.error;
        _errorMessage = 'Stream unavailable. Try another channel.';
        notifyListeners();
      }
    });
  }

  // -- Dispose ------------------------------------------------------------------

  @override
  void dispose() {
    _controlsTimer?.cancel();
    _player.dispose();
    super.dispose();
  }
}
