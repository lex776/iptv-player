import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/epg_program.dart';
import '../services/epg_parser.dart';

class EpgProvider extends ChangeNotifier {
  final EpgParser _parser;

  // -- State ------------------------------------------------------------------

  final Map<String, List<EpgProgram>> _programs = {};
  bool _loading = false;
  String? _error;
  DateTime? _lastFetched;
  String? _activeUrl;
  Timer? _refreshTimer;

  // -- Constructor ------------------------------------------------------------------

  EpgProvider() : _parser = EpgParser();

  // -- Getters ------------------------------------------------------------------

  bool get isLoading => _loading;
  String? get error => _error;
  DateTime? get lastFetched => _lastFetched;
  bool get hasData => _programs.isNotEmpty;
  String? get activeUrl => _activeUrl;

  // -- EPG queries ------------------------------------------------------------------

  EpgProgram? getCurrentProgram(String channelId) {
    final list = _programs[channelId];
    if (list == null || list.isEmpty) return null;
    final now = DateTime.now();
    try {
      return list.firstWhere(
        (p) => p.start.isBefore(now) && p.stop.isAfter(now),
      );
    } catch (_) {
      return null;
    }
  }

  EpgProgram? getNextProgram(String channelId) {
    final current = getCurrentProgram(channelId);
    if (current == null) return null;
    final list = _programs[channelId]!;
    final idx = list.indexOf(current);
    return (idx >= 0 && idx < list.length - 1) ? list[idx + 1] : null;
  }

  List<EpgProgram> getUpcomingPrograms(String channelId, {int count = 6}) {
    final list = _programs[channelId];
    if (list == null || list.isEmpty) return [];
    final now = DateTime.now();
    return list.where((p) => p.stop.isAfter(now)).take(count).toList();
  }

  List<EpgProgram> getTodayPrograms(String channelId) {
    final list = _programs[channelId];
    if (list == null || list.isEmpty) return [];
    final now = DateTime.now();
    final dayStart = DateTime(now.year, now.month, now.day);
    final dayEnd = dayStart.add(const Duration(days: 1));
    return list
        .where((p) => p.stop.isAfter(dayStart) && p.start.isBefore(dayEnd))
        .toList();
  }

  bool hasEpgForChannel(String channelId) =>
      _programs.containsKey(channelId) && _programs[channelId]!.isNotEmpty;

  // -- Loading ------------------------------------------------------------------

  Future<void> loadEpg(String url, {bool forceRefresh = false}) async {
    // Cache: skip if same URL fetched within 60 minutes
    if (!forceRefresh &&
        _activeUrl == url &&
        _lastFetched != null &&
        DateTime.now().difference(_lastFetched!).inMinutes < 60) {
      return;
    }

    _loading = true;
    _error = null;
    _activeUrl = url;
    notifyListeners();

    final result = await _parser.parseFromUrl(url);

    _loading = false;

    if (result.error != null) {
      _error = result.error;
      notifyListeners();
      return;
    }

    _programs
      ..clear()
      ..addAll(result.programs);
    _lastFetched = DateTime.now();
    notifyListeners();

    // Auto-refresh every 60 minutes
    _refreshTimer?.cancel();
    _refreshTimer = Timer.periodic(const Duration(minutes: 60), (_) {
      loadEpg(url, forceRefresh: true);
    });
  }

  Future<void> refresh() async {
    if (_activeUrl == null) return;
    await loadEpg(_activeUrl!, forceRefresh: true);
  }

  void clear() {
    _refreshTimer?.cancel();
    _programs.clear();
    _activeUrl = null;
    _lastFetched = null;
    _error = null;
    notifyListeners();
  }

  // -- Dispose ------------------------------------------------------------------

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }
}
