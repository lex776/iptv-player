import 'package:collection/collection.dart';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/channel.dart';
import '../models/playlist.dart';
import '../models/category.dart';
import '../services/m3u_parser.dart';
import '../services/storage_service.dart';
import '../core/constants/app_strings.dart';

enum LoadState { idle, loading, success, error }

class PlaylistProvider extends ChangeNotifier {
  final StorageService storageService;
  final M3uParser _m3uParser;
  static const _uuid = Uuid();

  // -- Internal state ------------------------------------------------------------

  LoadState _loadState = LoadState.idle;
  String? _error;
  List<Playlist> _playlists = [];
  Playlist? _currentPlaylist;
  List<Channel> _allChannels = [];
  List<ChannelCategory> _categories = [];
  String _selectedCategory = AppStrings.allChannels;
  String _searchQuery = '';
  List<Channel> _favorites = [];
  List<String> _recentIds = [];

  // -- Constructor ------------------------------------------------------------------

  PlaylistProvider({required this.storageService}) : _m3uParser = M3uParser() {
    _loadFromStorage();
  }

  // -- Public getters ------------------------------------------------------------------

  LoadState get loadState => _loadState;
  String? get error => _error;
  List<Playlist> get playlists => List.unmodifiable(_playlists);
  Playlist? get currentPlaylist => _currentPlaylist;
  List<ChannelCategory> get categories => List.unmodifiable(_categories);
  String get selectedCategory => _selectedCategory;
  String get searchQuery => _searchQuery;
  List<Channel> get favorites => List.unmodifiable(_favorites);
  List<Channel> get allChannels => List.unmodifiable(_allChannels);
  bool get isLoading => _loadState == LoadState.loading;
  bool get hasError => _loadState == LoadState.error;
  bool get hasPlaylists => _playlists.isNotEmpty;
  bool get hasChannels => _allChannels.isNotEmpty;

  /// Channels currently visible after category + search filtering
  List<Channel> get filteredChannels {
    List<Channel> base;

    switch (_selectedCategory) {
      case AppStrings.favorites:
        base = List.from(_favorites);
        break;
      case AppStrings.recentlyWatched:
        base = _recentlyWatchedChannels();
        break;
      case AppStrings.allChannels:
        base = List.from(_allChannels);
        break;
      default:
        final cat = _categories.firstWhere(
          (c) => c.name == _selectedCategory,
          orElse: () => const ChannelCategory(name: '', channels: []),
        );
        base = List.from(cat.channels);
    }

    if (_searchQuery.isEmpty) return base;

    final q = _searchQuery.toLowerCase();
    return base
        .where((c) =>
            c.name.toLowerCase().contains(q) ||
            (c.groupTitle?.toLowerCase().contains(q) ?? false) ||
            (c.tvgName?.toLowerCase().contains(q) ?? false))
        .toList();
  }

  List<Channel> _recentlyWatchedChannels() {
    final map = {for (final c in _allChannels) c.id: c};
    return _recentIds.map((id) => map[id]).whereType<Channel>().toList();
  }

  // -- Initialization ------------------------------------------------------------------

  void _loadFromStorage() {
    _playlists = storageService.getAllPlaylists();
    _favorites = storageService.getFavorites();
    _recentIds = storageService.getRecentlyWatchedIds();

    // Auto-restore last used playlist
    final lastId = storageService.lastPlaylistId;
    Playlist? toLoad;

    if (lastId != null) {
      toLoad = _playlists.where((p) => p.id == lastId).firstOrNull;
    }
    toLoad ??= _playlists.firstOrNull;

    if (toLoad != null) {
      loadPlaylist(toLoad);
    }
  }

  // -- Playlist management ------------------------------------------------------------------

  Future<void> addPlaylistFromUrl(
    String url,
    String name, {
    String? epgUrl,
  }) async {
    _setLoading();

    final result = await _m3uParser.parseFromUrl(url);
    if (result.error != null) {
      _setError(result.error!);
      return;
    }
    if (result.channels.isEmpty) {
      _setError(AppStrings.noChannels);
      return;
    }

    final playlist = Playlist(
      id: _uuid.v4(),
      name: name.trim().isNotEmpty ? name.trim() : _hostFromUrl(url),
      source: url,
      epgUrl: epgUrl ?? result.epgUrl,
      createdAt: DateTime.now(),
      lastRefreshed: DateTime.now(),
      channelCount: result.channels.length,
    );

    await storageService.savePlaylist(playlist);
    _playlists = storageService.getAllPlaylists();

    _currentPlaylist = playlist;
    storageService.lastPlaylistId = playlist.id;
    _applyChannels(result.channels);
    _setSuccess();
  }

  Future<void> addPlaylistFromFile(String filePath, String name) async {
    _setLoading();

    final result = await _m3uParser.parseFromFile(filePath);
    if (result.error != null) {
      _setError(result.error!);
      return;
    }
    if (result.channels.isEmpty) {
      _setError(AppStrings.noChannels);
      return;
    }

    final playlist = Playlist(
      id: _uuid.v4(),
      name: name.trim().isNotEmpty ? name.trim() : filePath.split('/').last,
      source: filePath,
      isLocal: true,
      epgUrl: result.epgUrl,
      createdAt: DateTime.now(),
      lastRefreshed: DateTime.now(),
      channelCount: result.channels.length,
    );

    await storageService.savePlaylist(playlist);
    _playlists = storageService.getAllPlaylists();

    _currentPlaylist = playlist;
    storageService.lastPlaylistId = playlist.id;
    _applyChannels(result.channels);
    _setSuccess();
  }

  Future<void> loadPlaylist(Playlist playlist) async {
    _setLoading();
    _currentPlaylist = playlist;
    storageService.lastPlaylistId = playlist.id;

    final result = playlist.isLocal
        ? await _m3uParser.parseFromFile(playlist.source)
        : await _m3uParser.parseFromUrl(playlist.source);

    if (result.error != null) {
      _setError(result.error!);
      return;
    }

    _applyChannels(result.channels);
    await storageService.updatePlaylistRefreshTime(playlist.id);
    await storageService.updatePlaylistChannelCount(
        playlist.id, result.channels.length);
    _playlists = storageService.getAllPlaylists();
    _setSuccess();
  }

  Future<void> refreshCurrentPlaylist() async {
    if (_currentPlaylist == null) return;
    await loadPlaylist(_currentPlaylist!);
  }

  Future<void> switchPlaylist(Playlist playlist) async {
    if (_currentPlaylist?.id == playlist.id) return;
    await loadPlaylist(playlist);
  }

  Future<void> deletePlaylist(String id) async {
    await storageService.deletePlaylist(id);
    _playlists = storageService.getAllPlaylists();

    if (_currentPlaylist?.id == id) {
      _currentPlaylist = null;
      _allChannels = [];
      _categories = [];
      _selectedCategory = AppStrings.allChannels;

      if (_playlists.isNotEmpty) {
        await loadPlaylist(_playlists.first);
        return;
      }
    }

    notifyListeners();
  }

  Future<void> updatePlaylistEpgUrl(String playlistId, String epgUrl) async {
    await storageService.updatePlaylistEpgUrl(playlistId, epgUrl);
    _playlists = storageService.getAllPlaylists();
    if (_currentPlaylist?.id == playlistId) {
      _currentPlaylist = storageService.getPlaylist(playlistId);
    }
    notifyListeners();
  }

  // -- Category & search ------------------------------------------------------------------

  void selectCategory(String name) {
    if (_selectedCategory == name) return;
    _selectedCategory = name;
    notifyListeners();
  }

  void setSearchQuery(String query) {
    if (_searchQuery == query) return;
    _searchQuery = query;
    notifyListeners();
  }

  void clearSearch() => setSearchQuery('');

  // -- Favorites ------------------------------------------------------------------

  Future<void> toggleFavorite(Channel channel) async {
    final nowFav = await storageService.toggleFavorite(channel);
    _favorites = storageService.getFavorites();

    // Reflect change in allChannels list
    final idx = _allChannels.indexWhere((c) => c.id == channel.id);
    if (idx != -1) {
      _allChannels[idx] = _allChannels[idx].copyWith(isFavorite: nowFav);
    }

    notifyListeners();
  }

  bool isFavorite(String channelId) => storageService.isFavorite(channelId);

  // -- Recently watched ------------------------------------------------------------------

  Future<void> markAsWatched(Channel channel) async {
    await storageService.addToRecentlyWatched(channel.id);
    _recentIds = storageService.getRecentlyWatchedIds();
    notifyListeners();
  }

  // -- Private helpers ------------------------------------------------------------------

  void _applyChannels(List<Channel> channels) {
    _allChannels = channels
        .map((c) => c.copyWith(
              isFavorite: storageService.isFavorite(c.id),
            ))
        .toList();
    _favorites = storageService.getFavorites();
    _buildCategories();
  }

  void _buildCategories() {
    final groups = <String, List<Channel>>{};
    for (final ch in _allChannels) {
      groups.putIfAbsent(ch.groupTitle ?? 'Other', () => []).add(ch);
    }

    _categories = groups.entries
        .map((e) => ChannelCategory(
              name: e.key,
              channels: e.value,
              iconEmoji: _emojiForCategory(e.key),
            ))
        .toList()
      ..sort((a, b) {
        final oa = _orderForCategory(a.name);
        final ob = _orderForCategory(b.name);
        if (oa != ob) return oa.compareTo(ob);
        return a.name.compareTo(b.name);
      });

    _selectedCategory = AppStrings.allChannels;
  }

  int _orderForCategory(String name) {
    final l = name.toLowerCase();
    if (l.contains('news')) return 0;
    if (l.contains('sport')) return 1;
    if (l.contains('movie') || l.contains('film') || l.contains('cinema')) {
      return 2;
    }
    if (l.contains('series') ||
        l.contains('tv show') ||
        l.contains('entertain')) {
      return 3;
    }
    if (l.contains('kids') || l.contains('children') || l.contains('cartoon')) {
      return 4;
    }
    if (l.contains('music')) return 5;
    if (l.contains('document')) return 6;
    if (l.contains('other') || l.contains('general')) return 99;
    return 50;
  }

  String _emojiForCategory(String name) {
    final l = name.toLowerCase();
    if (l.contains('news')) return '\u{1F4F0}';
    if (l.contains('sport')) return '\u{26BD}';
    if (l.contains('movie') || l.contains('film')) return '\u{1F3AC}';
    if (l.contains('kids') || l.contains('children')) return '\u{1F9D2}';
    if (l.contains('music')) return '\u{1F3B5}';
    if (l.contains('document')) return '\u{1F4DA}';
    if (l.contains('entertain') || l.contains('series')) return '\u{1F3AD}';
    if (l.contains('business') || l.contains('finance')) return '\u{1F4BC}';
    if (l.contains('travel')) return '\u{2708}\u{FE0F}';
    if (l.contains('food') || l.contains('cook')) return '\u{1F37D}\u{FE0F}';
    if (l.contains('tech')) return '\u{1F4BB}';
    if (l.contains('nature') || l.contains('animal')) return '\u{1F33F}';
    return '\u{1F4FA}';
  }

  String _hostFromUrl(String url) {
    try {
      return Uri.parse(url).host;
    } catch (_) {
      return 'Playlist';
    }
  }

  void _setLoading() {
    _loadState = LoadState.loading;
    _error = null;
    notifyListeners();
  }

  void _setError(String e) {
    _loadState = LoadState.error;
    _error = e;
    notifyListeners();
  }

  void _setSuccess() {
    _loadState = LoadState.success;
    _error = null;
    notifyListeners();
  }
}
