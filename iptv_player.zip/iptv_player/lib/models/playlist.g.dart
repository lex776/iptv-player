// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'playlist.dart';

class PlaylistAdapter extends TypeAdapter<Playlist> {
  @override
  final int typeId = 1;

  @override
  Playlist read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Playlist(
      id: fields[0] as String,
      name: fields[1] as String,
      source: fields[2] as String,
      isLocal: fields[3] as bool? ?? false,
      epgUrl: fields[4] as String?,
      createdAt: fields[5] as DateTime,
      lastRefreshed: fields[6] as DateTime?,
      channelCount: fields[7] as int? ?? 0,
    );
  }

  @override
  void write(BinaryWriter writer, Playlist obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.source)
      ..writeByte(3)
      ..write(obj.isLocal)
      ..writeByte(4)
      ..write(obj.epgUrl)
      ..writeByte(5)
      ..write(obj.createdAt)
      ..writeByte(6)
      ..write(obj.lastRefreshed)
      ..writeByte(7)
      ..write(obj.channelCount);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PlaylistAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
