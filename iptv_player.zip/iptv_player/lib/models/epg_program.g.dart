// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'epg_program.dart';

class EpgProgramAdapter extends TypeAdapter<EpgProgram> {
  @override
  final int typeId = 2;

  @override
  EpgProgram read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return EpgProgram(
      channelId: fields[0] as String,
      title: fields[1] as String,
      description: fields[2] as String?,
      start: fields[3] as DateTime,
      stop: fields[4] as DateTime,
      category: fields[5] as String?,
      icon: fields[6] as String?,
      rating: fields[7] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, EpgProgram obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.channelId)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.description)
      ..writeByte(3)
      ..write(obj.start)
      ..writeByte(4)
      ..write(obj.stop)
      ..writeByte(5)
      ..write(obj.category)
      ..writeByte(6)
      ..write(obj.icon)
      ..writeByte(7)
      ..write(obj.rating);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is EpgProgramAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
