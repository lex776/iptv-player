import 'package:hive/hive.dart';

part 'epg_program.g.dart';

@HiveType(typeId: 2)
class EpgProgram {
  @HiveField(0)
  final String channelId;

  @HiveField(1)
  final String title;

  @HiveField(2)
  final String? description;

  @HiveField(3)
  final DateTime start;

  @HiveField(4)
  final DateTime stop;

  @HiveField(5)
  final String? category;

  @HiveField(6)
  final String? icon;

  @HiveField(7)
  final String? rating;

  const EpgProgram({
    required this.channelId,
    required this.title,
    this.description,
    required this.start,
    required this.stop,
    this.category,
    this.icon,
    this.rating,
  });

  bool get isLive {
    final now = DateTime.now();
    return now.isAfter(start) && now.isBefore(stop);
  }

  double get progressPercent {
    final now = DateTime.now();
    if (now.isBefore(start)) return 0.0;
    if (now.isAfter(stop)) return 1.0;
    final total = stop.difference(start).inSeconds;
    final elapsed = now.difference(start).inSeconds;
    if (total <= 0) return 1.0;
    return elapsed / total;
  }

  String get durationString {
    final dur = stop.difference(start);
    if (dur.inHours > 0) return '${dur.inHours}h ${dur.inMinutes % 60}m';
    return '${dur.inMinutes}m';
  }
}
