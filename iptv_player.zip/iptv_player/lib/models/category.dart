import 'package:equatable/equatable.dart';
import 'channel.dart';

class ChannelCategory extends Equatable {
  final String name;
  final List<Channel> channels;
  final String? iconEmoji;

  const ChannelCategory({
    required this.name,
    required this.channels,
    this.iconEmoji,
  });

  int get count => channels.length;

  ChannelCategory copyWith({
    String? name,
    List<Channel>? channels,
    String? iconEmoji,
  }) {
    return ChannelCategory(
      name: name ?? this.name,
      channels: channels ?? this.channels,
      iconEmoji: iconEmoji ?? this.iconEmoji,
    );
  }

  @override
  List<Object?> get props => [name, channels.length];
}
