// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'channel.dart';

class ChannelAdapter extends TypeAdapter<Channel> {
  @override
  final int typeId = 0;

  @override
  Channel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Channel(
      id: fields[0] as String,
      name: fields[1] as String,
      url: fields[2] as String,
      logoUrl: fields[3] as String?,
      groupTitle: fields[4] as String?,
      tvgId: fields[5] as String?,
      tvgName: fields[6] as String?,
      language: fields[7] as String?,
      country: fields[8] as String?,
      isFavorite: fields[9] as bool? ?? false,
      lastWatched: fields[10] as DateTime?,
    );
  }

  @override
  void write(BinaryWriter writer, Channel obj) {
    writer
      ..writeByte(11)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.url)
      ..writeByte(3)
      ..write(obj.logoUrl)
      ..writeByte(4)
      ..write(obj.groupTitle)
      ..writeByte(5)
      ..write(obj.tvgId)
      ..writeByte(6)
      ..write(obj.tvgName)
      ..writeByte(7)
      ..write(obj.language)
      ..writeByte(8)
      ..write(obj.country)
      ..writeByte(9)
      ..write(obj.isFavorite)
      ..writeByte(10)
      ..write(obj.lastWatched);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ChannelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
