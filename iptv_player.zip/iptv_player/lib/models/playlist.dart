import 'package:hive/hive.dart';

part 'playlist.g.dart';

@HiveType(typeId: 1)
class Playlist {
  @HiveField(0)
  final String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  String source; // URL or local path

  @HiveField(3)
  final bool isLocal;

  @HiveField(4)
  String? epgUrl;

  @HiveField(5)
  final DateTime createdAt;

  @HiveField(6)
  DateTime? lastRefreshed;

  @HiveField(7)
  int channelCount;

  Playlist({
    required this.id,
    required this.name,
    required this.source,
    this.isLocal = false,
    this.epgUrl,
    required this.createdAt,
    this.lastRefreshed,
    this.channelCount = 0,
  });
}
