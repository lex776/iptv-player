import 'package:equatable/equatable.dart';
import 'package:hive/hive.dart';

part 'channel.g.dart';

@HiveType(typeId: 0)
class Channel extends Equatable {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String name;

  @HiveField(2)
  final String url;

  @HiveField(3)
  final String? logoUrl;

  @HiveField(4)
  final String? groupTitle;

  @HiveField(5)
  final String? tvgId;

  @HiveField(6)
  final String? tvgName;

  @HiveField(7)
  final String? language;

  @HiveField(8)
  final String? country;

  @HiveField(9)
  final bool isFavorite;

  @HiveField(10)
  final DateTime? lastWatched;

  const Channel({
    required this.id,
    required this.name,
    required this.url,
    this.logoUrl,
    this.groupTitle,
    this.tvgId,
    this.tvgName,
    this.language,
    this.country,
    this.isFavorite = false,
    this.lastWatched,
  });

  Channel copyWith({
    String? id,
    String? name,
    String? url,
    String? logoUrl,
    String? groupTitle,
    String? tvgId,
    String? tvgName,
    String? language,
    String? country,
    bool? isFavorite,
    DateTime? lastWatched,
  }) {
    return Channel(
      id: id ?? this.id,
      name: name ?? this.name,
      url: url ?? this.url,
      logoUrl: logoUrl ?? this.logoUrl,
      groupTitle: groupTitle ?? this.groupTitle,
      tvgId: tvgId ?? this.tvgId,
      tvgName: tvgName ?? this.tvgName,
      language: language ?? this.language,
      country: country ?? this.country,
      isFavorite: isFavorite ?? this.isFavorite,
      lastWatched: lastWatched ?? this.lastWatched,
    );
  }

  @override
  List<Object?> get props => [
        id,
        name,
        url,
        logoUrl,
        groupTitle,
        tvgId,
        isFavorite,
        lastWatched,
      ];
}
