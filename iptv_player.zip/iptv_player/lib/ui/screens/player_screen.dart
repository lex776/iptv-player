import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_colors.dart';
import '../../providers/player_provider.dart';
import '../../providers/playlist_provider.dart';
import '../widgets/shared/player_controls.dart';
import '../widgets/tv/tv_epg_overlay.dart';

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key, required this.channelIndex});

  final int channelIndex;

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  final FocusNode _kbFocus = FocusNode();
  PlayerProvider? _playerRef;
  bool _started = false;
  bool _epgVisible = false;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _playerRef = context.read<PlayerProvider>();
  }

  Future<void> _start() async {
    if (_started || !mounted) return;
    _started = true;

    final playlist = context.read<PlaylistProvider>();
    final player = context.read<PlayerProvider>();
    final list = playlist.filteredChannels;
    if (list.isEmpty) return;

    final idx = widget.channelIndex.clamp(0, list.length - 1);
    await player.playChannel(list[idx], idx, list);
    await playlist.markAsWatched(list[idx]);
  }

  @override
  void dispose() {
    _kbFocus.dispose();
    final ref = _playerRef;
    Future.microtask(() => ref?.stop());
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _exit() {
    if (Navigator.of(context).canPop()) Navigator.of(context).pop();
  }

  KeyEventResult _handleKey(FocusNode node, KeyEvent event) {
    if (event is! KeyDownEvent) return KeyEventResult.ignored;

    final player = context.read<PlayerProvider>();
    final key = event.logicalKey;

    if (key == LogicalKeyboardKey.arrowUp ||
        key == LogicalKeyboardKey.channelUp) {
      player.playPrevious();
      return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.arrowDown ||
        key == LogicalKeyboardKey.channelDown) {
      player.playNext();
      return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.select ||
        key == LogicalKeyboardKey.enter ||
        key == LogicalKeyboardKey.numpadEnter) {
      player.toggleControls();
      return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.mediaPlayPause ||
        key == LogicalKeyboardKey.mediaPlay ||
        key == LogicalKeyboardKey.mediaPause ||
        key == LogicalKeyboardKey.space) {
      player.togglePlayPause();
      return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.contextMenu) {
      setState(() => _epgVisible = !_epgVisible);
      return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.arrowRight) {
      player.cycleAspectRatio();
      player.showControls();
      return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.arrowLeft) {
      player.showControls();
      return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.escape ||
        key == LogicalKeyboardKey.goBack ||
        key == LogicalKeyboardKey.mediaStop) {
      if (_epgVisible) {
        setState(() => _epgVisible = false);
      } else {
        _exit();
      }
      return KeyEventResult.handled;
    }

    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final mode = player.aspectRatioMode;

    final BoxFit fit = mode == AspectRatioMode.fill
        ? BoxFit.cover
        : BoxFit.contain;
    final double? ratio = mode.ratio > 0 ? mode.ratio : null;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Focus(
        focusNode: _kbFocus,
        autofocus: true,
        onKeyEvent: _handleKey,
        child: GestureDetector(
          onTap: player.toggleControls,
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Video surface
              Center(
                child: Video(
                  controller: player.controller,
                  fit: fit,
                  aspectRatio: ratio,
                  controls: NoVideoControls,
                  fill: Colors.black,
                ),
              ),

              // Buffering / loading spinner
              if (player.status == PlayerStatus.loading || player.isBuffering)
                const Center(
                  child: CircularProgressIndicator(
                    valueColor:
                        AlwaysStoppedAnimation<Color>(AppColors.accent),
                  ),
                ),

              // Error message
              if (player.hasError)
                Center(
                  child: Container(
                    margin: const EdgeInsets.all(32),
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                          color: AppColors.live.withOpacity(0.5)),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.error_outline_rounded,
                            color: AppColors.live, size: 40),
                        const SizedBox(height: 12),
                        Text(
                          player.errorMessage ?? 'Playback error',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              color: AppColors.textPrimary, fontSize: 15),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (player.hasNext)
                              ElevatedButton(
                                onPressed: player.playNext,
                                child: const Text('Next channel'),
                              ),
                            const SizedBox(width: 10),
                            OutlinedButton(
                              onPressed: _exit,
                              child: const Text('Back'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

              // Controls overlay
              AnimatedOpacity(
                opacity: player.controlsVisible ? 1.0 : 0.0,
                duration: const Duration(milliseconds: 200),
                child: IgnorePointer(
                  ignoring: !player.controlsVisible,
                  child: PlayerControls(
                    onBack: _exit,
                    onToggleEpg: () =>
                        setState(() => _epgVisible = !_epgVisible),
                    onToggleChannels: player.toggleChannelList,
                  ),
                ),
              ),

              // Channel list side panel
              if (player.channelListVisible)
                Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    width: 340,
                    color: const Color(0xF00A0A0F),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 16, 8, 8),
                          child: Row(
                            children: [
                              const Expanded(
                                child: Text(
                                  'Channels',
                                  style: TextStyle(
                                    color: AppColors.textPrimary,
                                    fontSize: 17,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              IconButton(
                                onPressed: player.hideChannelList,
                                icon: const Icon(Icons.close_rounded,
                                    color: AppColors.textSecondary),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: ListView.builder(
                            itemCount: player.channelList.length,
                            itemBuilder: (context, i) {
                              final ch = player.channelList[i];
                              final isCurrent =
                                  i == player.currentChannelIndex;
                              return ListTile(
                                dense: true,
                                selected: isCurrent,
                                selectedTileColor: AppColors.focusBackground,
                                title: Text(
                                  ch.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: isCurrent
                                        ? AppColors.accentLight
                                        : AppColors.textPrimary,
                                    fontSize: 14,
                                  ),
                                ),
                                onTap: () {
                                  player.playChannel(
                                      ch, i, player.channelList);
                                  player.hideChannelList();
                                },
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              // EPG overlay
              if (_epgVisible && player.currentChannel != null)
                TvEpgOverlay(
                  channel: player.currentChannel!,
                  onClose: () => setState(() => _epgVisible = false),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
