import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../providers/epg_provider.dart';
import '../../providers/playlist_provider.dart';
import '../widgets/shared/focusable_widget.dart';
import '../widgets/shared/playlist_input_dialog.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _addPlaylist(BuildContext context) async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const PlaylistInputDialog(),
    );
  }

  Future<void> _confirmDelete(
      BuildContext context, PlaylistProvider provider, String id) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Delete playlist?',
            style: TextStyle(color: AppColors.textPrimary)),
        content: const Text(
          'This removes the playlist from the app. Channels can be re-added anytime.',
          style: TextStyle(color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text(AppStrings.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text(AppStrings.delete,
                style: TextStyle(color: AppColors.live)),
          ),
        ],
      ),
    );
    if (ok == true) await provider.deletePlaylist(id);
  }

  Future<void> _editEpg(
      BuildContext context, PlaylistProvider provider) async {
    final playlist = provider.currentPlaylist;
    if (playlist == null) return;

    final ctrl = TextEditingController(text: playlist.epgUrl ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text(AppStrings.epgSettings,
            style: TextStyle(color: AppColors.textPrimary)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: AppColors.textPrimary),
          decoration: const InputDecoration(hintText: AppStrings.epgUrl),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text(AppStrings.cancel),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(ctrl.text.trim()),
            child: const Text(AppStrings.save),
          ),
        ],
      ),
    );

    if (result != null && result.isNotEmpty) {
      await provider.updatePlaylistEpgUrl(playlist.id, result);
      if (context.mounted) {
        await context.read<EpgProvider>().loadEpg(result, forceRefresh: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PlaylistProvider>();
    final epg = context.watch<EpgProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.settings)),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 12),
        children: [
          _sectionTitle(AppStrings.managePlaylists),
          ...provider.playlists.map(
            (p) => TVFocusTile(
              title: p.name,
              subtitle: '${p.channelCount} channels'
                  '${p.isLocal ? ' - local file' : ''}'
                  '${provider.currentPlaylist?.id == p.id ? ' - active' : ''}',
              leading: Icon(
                provider.currentPlaylist?.id == p.id
                    ? Icons.radio_button_checked_rounded
                    : Icons.radio_button_unchecked_rounded,
                color: provider.currentPlaylist?.id == p.id
                    ? AppColors.accent
                    : AppColors.textDisabled,
                size: 20,
              ),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline_rounded,
                    color: AppColors.textDisabled),
                onPressed: () => _confirmDelete(context, provider, p.id),
              ),
              onPressed: () => provider.switchPlaylist(p),
            ),
          ),
          TVFocusTile(
            title: AppStrings.addPlaylist,
            leading: const Icon(Icons.add_rounded,
                color: AppColors.accent, size: 20),
            onPressed: () => _addPlaylist(context),
          ),

          const SizedBox(height: 14),
          _sectionTitle(AppStrings.epgSettings),
          TVFocusTile(
            title: 'EPG URL (XMLTV)',
            subtitle: provider.currentPlaylist?.epgUrl ?? 'not set',
            leading: const Icon(Icons.event_note_rounded,
                color: AppColors.textSecondary, size: 20),
            onPressed: () => _editEpg(context, provider),
          ),
          TVFocusTile(
            title: 'Refresh EPG now',
            subtitle: epg.isLoading
                ? 'loading...'
                : (epg.hasData ? 'data loaded' : AppStrings.noEpgData),
            leading: const Icon(Icons.refresh_rounded,
                color: AppColors.textSecondary, size: 20),
            onPressed: () => epg.refresh(),
          ),

          const SizedBox(height: 14),
          _sectionTitle(AppStrings.managePlaylists + ' - data'),
          TVFocusTile(
            title: 'Refresh current playlist',
            leading: const Icon(Icons.sync_rounded,
                color: AppColors.textSecondary, size: 20),
            onPressed: () => provider.refreshCurrentPlaylist(),
          ),

          const SizedBox(height: 14),
          _sectionTitle(AppStrings.about),
          const Padding(
            padding: EdgeInsets.fromLTRB(22, 6, 22, 30),
            child: Text(
              'IPTV Player v1.0.0\n'
              'Supports M3U / M3U8 playlists, XMLTV EPG, HLS and DASH streams.\n\n'
              'Remote control: Up/Down - change channel, OK - show controls, '
              'Right - aspect ratio, Menu - program guide, Back - exit.',
              style: TextStyle(color: AppColors.textDisabled, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 12, 22, 6),
        child: Text(
          text.toUpperCase(),
          style: const TextStyle(
            color: AppColors.accentLight,
            fontSize: 12,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.1,
          ),
        ),
      );
}
