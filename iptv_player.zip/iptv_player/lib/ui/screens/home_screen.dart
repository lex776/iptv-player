import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/utils/platform_utils.dart';
import '../../providers/epg_provider.dart';
import '../../providers/playlist_provider.dart';
import '../widgets/mobile/mobile_category_tabs.dart';
import '../widgets/mobile/mobile_channel_list.dart';
import '../widgets/shared/playlist_input_dialog.dart';
import '../widgets/tv/tv_category_rail.dart';
import '../widgets/tv/tv_channel_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchCtrl = TextEditingController();
  String? _epgLoadedFor;

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _maybeLoadEpg(PlaylistProvider playlist) {
    final url = playlist.currentPlaylist?.epgUrl;
    if (url == null || url.isEmpty) return;
    if (_epgLoadedFor == url) return;
    _epgLoadedFor = url;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<EpgProvider>().loadEpg(url);
    });
  }

  Future<void> _addPlaylist() async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const PlaylistInputDialog(),
    );
  }

  void _openPlayer(int index) {
    context.push('/player', extra: {'channelIndex': index});
  }

  @override
  Widget build(BuildContext context) {
    final playlist = context.watch<PlaylistProvider>();
    _maybeLoadEpg(playlist);

    if (playlist.isLoading && !playlist.hasChannels) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(AppColors.accent),
          ),
        ),
      );
    }

    if (!playlist.hasPlaylists) return _buildEmptyState(playlist);

    return PlatformUtils.isTV
        ? _buildTvLayout(playlist)
        : _buildMobileLayout(playlist);
  }

  // -- Empty state ------------------------------------------------------------

  Widget _buildEmptyState(PlaylistProvider playlist) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  gradient: AppColors.primaryGradient,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: const Icon(Icons.playlist_add_rounded,
                    color: Colors.white, size: 46),
              ),
              const SizedBox(height: 24),
              const Text(
                AppStrings.noPlaylists,
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Add an M3U playlist URL or load a local file to start.',
                textAlign: TextAlign.center,
                style:
                    TextStyle(color: AppColors.textSecondary, fontSize: 14),
              ),
              if (playlist.error != null) ...[
                const SizedBox(height: 14),
                Text(
                  playlist.error!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.live, fontSize: 13),
                ),
              ],
              const SizedBox(height: 26),
              ElevatedButton.icon(
                onPressed: _addPlaylist,
                icon: const Icon(Icons.add_rounded),
                label: const Text(AppStrings.addPlaylist),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // -- TV layout ------------------------------------------------------------

  Widget _buildTvLayout(PlaylistProvider playlist) {
    final channels = playlist.filteredChannels;

    return Scaffold(
      body: SafeArea(
        child: Row(
          children: [
            TvCategoryRail(onSettings: () => context.push('/settings')),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 20, 24, 12),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            playlist.selectedCategory,
                            style: const TextStyle(
                              color: AppColors.textPrimary,
                              fontSize: 26,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        Text(
                          '${channels.length} channels',
                          style: const TextStyle(
                              color: AppColors.textSecondary, fontSize: 14),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: channels.isEmpty
                        ? const Center(
                            child: Text(
                              AppStrings.noChannels,
                              style:
                                  TextStyle(color: AppColors.textDisabled),
                            ),
                          )
                        : GridView.builder(
                            padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 5,
                              childAspectRatio: 1.25,
                              crossAxisSpacing: 14,
                              mainAxisSpacing: 14,
                            ),
                            itemCount: channels.length,
                            itemBuilder: (context, i) => TvChannelCard(
                              channel: channels[i],
                              autofocus: false,
                              onPressed: () => _openPlayer(i),
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // -- Mobile layout ------------------------------------------------------------

  Widget _buildMobileLayout(PlaylistProvider playlist) {
    return Scaffold(
      appBar: AppBar(
        title: Text(playlist.currentPlaylist?.name ?? AppStrings.appName),
        actions: [
          IconButton(
            onPressed: playlist.isLoading
                ? null
                : () => playlist.refreshCurrentPlaylist(),
            icon: const Icon(Icons.refresh_rounded),
          ),
          IconButton(
            onPressed: _addPlaylist,
            icon: const Icon(Icons.playlist_add_rounded),
          ),
          IconButton(
            onPressed: () => context.push('/settings'),
            icon: const Icon(Icons.settings_rounded),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: TextField(
              controller: _searchCtrl,
              style: const TextStyle(color: AppColors.textPrimary),
              decoration: InputDecoration(
                hintText: 'Search channels...',
                prefixIcon: const Icon(Icons.search_rounded,
                    color: AppColors.textSecondary),
                suffixIcon: _searchCtrl.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear_rounded,
                            color: AppColors.textSecondary),
                        onPressed: () {
                          _searchCtrl.clear();
                          playlist.clearSearch();
                          setState(() {});
                        },
                      )
                    : null,
              ),
              onChanged: (v) {
                playlist.setSearchQuery(v);
                setState(() {});
              },
            ),
          ),
          const MobileCategoryTabs(),
          if (playlist.isLoading)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: LinearProgressIndicator(
                minHeight: 2,
                backgroundColor: AppColors.surfaceVariant,
                valueColor:
                    AlwaysStoppedAnimation<Color>(AppColors.accent),
              ),
            ),
          if (playlist.error != null)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                playlist.error!,
                style: const TextStyle(color: AppColors.live, fontSize: 13),
              ),
            ),
          Expanded(
            child: MobileChannelList(onChannelTap: _openPlayer),
          ),
        ],
      ),
    );
  }
}
