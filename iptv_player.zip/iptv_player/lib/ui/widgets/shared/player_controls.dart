import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../providers/epg_provider.dart';
import '../../../providers/player_provider.dart';

class PlayerControls extends StatelessWidget {
  const PlayerControls({
    super.key,
    required this.onBack,
    required this.onToggleEpg,
    required this.onToggleChannels,
  });

  final VoidCallback onBack;
  final VoidCallback onToggleEpg;
  final VoidCallback onToggleChannels;

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerProvider>();
    final epg = context.watch<EpgProvider>();
    final channel = player.currentChannel;
    if (channel == null) return const SizedBox.shrink();

    final tvgId = channel.tvgId;
    final current = tvgId != null ? epg.getCurrentProgram(tvgId) : null;
    final next = tvgId != null ? epg.getNextProgram(tvgId) : null;

    return Column(
      children: [
        // Top bar
        Container(
          padding: const EdgeInsets.fromLTRB(12, 14, 12, 22),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xCC000000), Colors.transparent],
            ),
          ),
          child: Row(
            children: [
              IconButton(
                onPressed: onBack,
                icon: const Icon(Icons.arrow_back_rounded,
                    color: Colors.white, size: 26),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      channel.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    if (current != null)
                      Text(
                        current.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 13,
                        ),
                      ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.live,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text(
                  'LIVE',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
        ),

        const Spacer(),

        // Bottom bar
        Container(
          padding: const EdgeInsets.fromLTRB(16, 26, 16, 18),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              colors: [Color(0xDD000000), Colors.transparent],
            ),
          ),
          child: Column(
            children: [
              if (current != null) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: current.progressPercent,
                    minHeight: 4,
                    backgroundColor: Colors.white24,
                    valueColor: const AlwaysStoppedAnimation<Color>(
                        AppColors.accent),
                  ),
                ),
                const SizedBox(height: 8),
                if (next != null)
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Next: ${next.title}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: AppColors.textSecondary, fontSize: 12),
                    ),
                  ),
                const SizedBox(height: 6),
              ],
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _CtrlButton(
                    icon: Icons.skip_previous_rounded,
                    label: 'Prev',
                    enabled: player.hasPrevious,
                    onPressed: player.playPrevious,
                  ),
                  _CtrlButton(
                    icon: player.isPlaying
                        ? Icons.pause_rounded
                        : Icons.play_arrow_rounded,
                    label: player.isPlaying ? 'Pause' : 'Play',
                    big: true,
                    onPressed: player.togglePlayPause,
                  ),
                  _CtrlButton(
                    icon: Icons.skip_next_rounded,
                    label: 'Next',
                    enabled: player.hasNext,
                    onPressed: player.playNext,
                  ),
                  _CtrlButton(
                    icon: Icons.aspect_ratio_rounded,
                    label: player.aspectRatioMode.label,
                    onPressed: player.cycleAspectRatio,
                  ),
                  _CtrlButton(
                    icon: player.muted
                        ? Icons.volume_off_rounded
                        : Icons.volume_up_rounded,
                    label: player.muted ? 'Muted' : 'Sound',
                    onPressed: player.toggleMute,
                  ),
                  _CtrlButton(
                    icon: Icons.event_note_rounded,
                    label: 'EPG',
                    onPressed: onToggleEpg,
                  ),
                  _CtrlButton(
                    icon: Icons.list_rounded,
                    label: 'Channels',
                    onPressed: onToggleChannels,
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _CtrlButton extends StatelessWidget {
  const _CtrlButton({
    required this.icon,
    required this.label,
    required this.onPressed,
    this.enabled = true,
    this.big = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onPressed;
  final bool enabled;
  final bool big;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            onPressed: enabled ? onPressed : null,
            icon: Icon(
              icon,
              size: big ? 42 : 28,
              color: enabled ? Colors.white : Colors.white30,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: 10,
              color: enabled ? AppColors.textSecondary : AppColors.textDisabled,
            ),
          ),
        ],
      ),
    );
  }
}
