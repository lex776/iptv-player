import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_strings.dart';
import '../../../providers/playlist_provider.dart';

class PlaylistInputDialog extends StatefulWidget {
  const PlaylistInputDialog({super.key});

  @override
  State<PlaylistInputDialog> createState() => _PlaylistInputDialogState();
}

class _PlaylistInputDialogState extends State<PlaylistInputDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _urlCtrl = TextEditingController();
  final _epgCtrl = TextEditingController();

  bool _isLoading = false;
  bool _showEpgField = false;
  String? _selectedFilePath;
  String? _selectedFileName;
  String? _errorText;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _urlCtrl.dispose();
    _epgCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['m3u', 'm3u8', 'txt'],
    );
    if (result != null && result.files.single.path != null) {
      setState(() {
        _selectedFilePath = result.files.single.path;
        _selectedFileName = result.files.single.name;
        _urlCtrl.clear();
        _errorText = null;
      });
    }
  }

  Future<void> _submit() async {
    if (_isLoading) return;

    final hasUrl = _urlCtrl.text.trim().isNotEmpty;
    final hasFile = _selectedFilePath != null;

    if (!hasUrl && !hasFile) {
      setState(() => _errorText = 'Please enter a URL or select a file');
      return;
    }

    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
      _errorText = null;
    });

    final provider = context.read<PlaylistProvider>();
    final name = _nameCtrl.text.trim();
    final epgUrl =
        _epgCtrl.text.trim().isNotEmpty ? _epgCtrl.text.trim() : null;

    if (hasFile) {
      await provider.addPlaylistFromFile(
        _selectedFilePath!,
        name.isNotEmpty ? name : _selectedFileName ?? 'My Playlist',
      );
    } else {
      await provider.addPlaylistFromUrl(
        _urlCtrl.text.trim(),
        name,
        epgUrl: epgUrl,
      );
    }

    if (!mounted) return;

    if (provider.hasError) {
      setState(() {
        _isLoading = false;
        _errorText = provider.error;
      });
    } else {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_isLoading,
      child: Dialog(
        backgroundColor: AppColors.surface,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        insetPadding:
            const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 540),
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Header
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            gradient: AppColors.primaryGradient,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.playlist_add_rounded,
                              color: Colors.white, size: 24),
                        ),
                        const SizedBox(width: 14),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(AppStrings.addPlaylist,
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.textPrimary)),
                              Text('M3U / M3U8 format',
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: AppColors.textSecondary)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 28),

                    // Playlist name
                    TextFormField(
                      controller: _nameCtrl,
                      style: const TextStyle(color: AppColors.textPrimary),
                      decoration: const InputDecoration(
                        hintText: AppStrings.playlistName,
                        prefixIcon: Icon(Icons.label_outline_rounded,
                            color: AppColors.textSecondary),
                      ),
                    ),
                    const SizedBox(height: 14),

                    // URL field
                    TextFormField(
                      controller: _urlCtrl,
                      style: const TextStyle(color: AppColors.textPrimary),
                      keyboardType: TextInputType.url,
                      enabled: _selectedFilePath == null,
                      decoration: InputDecoration(
                        hintText: AppStrings.playlistUrl,
                        prefixIcon: const Icon(Icons.link_rounded,
                            color: AppColors.textSecondary),
                        suffixIcon: _urlCtrl.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear,
                                    color: AppColors.textSecondary),
                                onPressed: () =>
                                    setState(() => _urlCtrl.clear()),
                              )
                            : null,
                      ),
                      validator: (v) {
                        if (_selectedFilePath != null) return null;
                        if (v == null || v.trim().isEmpty) {
                          return 'Enter a valid URL';
                        }
                        final url = v.trim().toLowerCase();
                        if (!url.startsWith('http://') &&
                            !url.startsWith('https://')) {
                          return 'URL must start with http:// or https://';
                        }
                        return null;
                      },
                      onChanged: (_) => setState(() {}),
                    ),
                    const SizedBox(height: 8),

                    // OR divider
                    const Row(
                      children: [
                        Expanded(
                            child:
                                Divider(color: AppColors.surfaceVariant)),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12),
                          child: Text('OR',
                              style: TextStyle(
                                  color: AppColors.textDisabled,
                                  fontSize: 12)),
                        ),
                        Expanded(
                            child:
                                Divider(color: AppColors.surfaceVariant)),
                      ],
                    ),
                    const SizedBox(height: 8),

                    // File picker button
                    OutlinedButton.icon(
                      onPressed: _isLoading ? null : _pickFile,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: _selectedFilePath != null
                            ? AppColors.accent
                            : AppColors.textSecondary,
                        side: BorderSide(
                            color: _selectedFilePath != null
                                ? AppColors.accent
                                : AppColors.textDisabled),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      icon: Icon(_selectedFilePath != null
                          ? Icons.check_circle_outline_rounded
                          : Icons.folder_open_rounded),
                      label: Text(
                        _selectedFileName ?? AppStrings.loadFromFile,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (_selectedFilePath != null) ...[
                      const SizedBox(height: 6),
                      TextButton(
                        onPressed: () => setState(() {
                          _selectedFilePath = null;
                          _selectedFileName = null;
                        }),
                        child: const Text('Clear file selection',
                            style:
                                TextStyle(color: AppColors.textSecondary)),
                      ),
                    ],
                    const SizedBox(height: 14),

                    // EPG toggle + field
                    GestureDetector(
                      onTap: () =>
                          setState(() => _showEpgField = !_showEpgField),
                      child: Row(
                        children: [
                          Icon(
                            _showEpgField
                                ? Icons.expand_less_rounded
                                : Icons.expand_more_rounded,
                            color: AppColors.textSecondary,
                            size: 18,
                          ),
                          const SizedBox(width: 6),
                          const Text(
                            'Add EPG URL (optional)',
                            style: TextStyle(
                                color: AppColors.textSecondary,
                                fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                    if (_showEpgField) ...[
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: _epgCtrl,
                        style:
                            const TextStyle(color: AppColors.textPrimary),
                        keyboardType: TextInputType.url,
                        decoration: const InputDecoration(
                          hintText: AppStrings.epgUrl,
                          prefixIcon: Icon(Icons.event_note_rounded,
                              color: AppColors.textSecondary),
                        ),
                      ),
                    ],

                    // Error message
                    if (_errorText != null) ...[
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppColors.live.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                              color: AppColors.live.withOpacity(0.4)),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.error_outline_rounded,
                                color: AppColors.live, size: 18),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(_errorText!,
                                  style: const TextStyle(
                                      color: AppColors.live,
                                      fontSize: 13)),
                            ),
                          ],
                        ),
                      ),
                    ],

                    const SizedBox(height: 24),

                    // Buttons
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: _isLoading
                                ? null
                                : () => Navigator.of(context).pop(),
                            style: OutlinedButton.styleFrom(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                              side: const BorderSide(
                                  color: AppColors.textDisabled),
                            ),
                            child: const Text(AppStrings.cancel,
                                style: TextStyle(
                                    color: AppColors.textSecondary)),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 2,
                          child: ElevatedButton(
                            onPressed: _isLoading ? null : _submit,
                            style: ElevatedButton.styleFrom(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                            ),
                            child: _isLoading
                                ? const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Colors.white,
                                    ),
                                  )
                                : const Text(AppStrings.loadPlaylist),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
