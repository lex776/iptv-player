import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../models/channel.dart';
import '../../../providers/epg_provider.dart';
import '../../../providers/playlist_provider.dart';

class MobileChannelList extends StatelessWidget {
  const MobileChannelList({super.key, required this.onChannelTap});

  final void Function(int index) onChannelTap;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PlaylistProvider>();
    final epg = context.watch<EpgProvider>();
    final channels = provider.filteredChannels;

    if (channels.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(30),
          child: Text(
            'No channels in this category',
            style: TextStyle(color: AppColors.textDisabled),
          ),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 24),
      itemCount: channels.length,
      itemBuilder: (context, i) {
        final Channel ch = channels[i];
        final tvgId = ch.tvgId;
        final current = tvgId != null ? epg.getCurrentProgram(tvgId) : null;

        return ListTile(
          onTap: () => onChannelTap(i),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          leading: Container(
            width: 52,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.surfaceVariant,
              borderRadius: BorderRadius.circular(8),
            ),
            child: ch.logoUrl != null
                ? Padding(
                    padding: const EdgeInsets.all(4),
                    child: CachedNetworkImage(
                      imageUrl: ch.logoUrl!,
                      fit: BoxFit.contain,
                      placeholder: (c, u) => const Icon(
                          Icons.live_tv_rounded,
                          color: AppColors.textDisabled,
                          size: 20),
                      errorWidget: (c, u, e) => const Icon(
                          Icons.live_tv_rounded,
                          color: AppColors.textDisabled,
                          size: 20),
                    ),
                  )
                : const Icon(Icons.live_tv_rounded,
                    color: AppColors.accent, size: 22),
          ),
          title: Text(
            ch.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: AppColors.textPrimary,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
          subtitle: Text(
            current?.title ?? (ch.groupTitle ?? ''),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
                color: AppColors.textSecondary, fontSize: 12),
          ),
          trailing: IconButton(
            onPressed: () => provider.toggleFavorite(ch),
            icon: Icon(
              ch.isFavorite ? Icons.star_rounded : Icons.star_border_rounded,
              color:
                  ch.isFavorite ? AppColors.warning : AppColors.textDisabled,
            ),
          ),
        );
      },
    );
  }
}
