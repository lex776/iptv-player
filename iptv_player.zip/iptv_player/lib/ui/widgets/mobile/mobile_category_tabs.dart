import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_strings.dart';
import '../../../providers/playlist_provider.dart';

class MobileCategoryTabs extends StatelessWidget {
  const MobileCategoryTabs({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PlaylistProvider>();
    final selected = provider.selectedCategory;

    final names = <String>[
      AppStrings.allChannels,
      AppStrings.favorites,
      AppStrings.recentlyWatched,
      ...provider.categories.map((c) => c.name),
    ];

    return SizedBox(
      height: 46,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: names.length,
        itemBuilder: (context, i) {
          final name = names[i];
          final isSel = name == selected;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
            child: GestureDetector(
              onTap: () => provider.selectCategory(name),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: isSel ? AppColors.accent : AppColors.surfaceVariant,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Center(
                  child: Text(
                    name,
                    style: TextStyle(
                      color:
                          isSel ? Colors.white : AppColors.textSecondary,
                      fontSize: 13,
                      fontWeight: isSel ? FontWeight.w700 : FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
