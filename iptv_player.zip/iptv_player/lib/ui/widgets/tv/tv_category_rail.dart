import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_strings.dart';
import '../../../providers/playlist_provider.dart';
import '../shared/focusable_widget.dart';

class TvCategoryRail extends StatelessWidget {
  const TvCategoryRail({super.key, this.onSettings});

  final VoidCallback? onSettings;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PlaylistProvider>();
    final selected = provider.selectedCategory;

    final items = <_RailItem>[
      _RailItem(AppStrings.allChannels, provider.allChannels.length, '\u{1F4FA}'),
      _RailItem(AppStrings.favorites, provider.favorites.length, '\u{2B50}'),
      _RailItem(AppStrings.recentlyWatched, -1, '\u{1F553}'),
      ...provider.categories.map(
        (c) => _RailItem(c.name, c.count, c.iconEmoji ?? '\u{1F4FA}'),
      ),
    ];

    return Container(
      width: 300,
      color: AppColors.surface,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 22, 20, 6),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    gradient: AppColors.primaryGradient,
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: const Icon(Icons.live_tv_rounded,
                      color: Colors.white, size: 18),
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'IPTV Player',
                    style: TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (provider.currentPlaylist != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
              child: Text(
                provider.currentPlaylist!.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    color: AppColors.textDisabled, fontSize: 12),
              ),
            ),
          const Divider(color: AppColors.surfaceVariant, height: 1),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: items.length,
              itemBuilder: (context, i) {
                final item = items[i];
                return TVFocusTile(
                  title: item.emoji + '  ' + item.name,
                  subtitle: item.count >= 0 ? '${item.count} channels' : null,
                  selected: item.name == selected,
                  autofocus: i == 0,
                  dense: true,
                  onPressed: () => provider.selectCategory(item.name),
                );
              },
            ),
          ),
          const Divider(color: AppColors.surfaceVariant, height: 1),
          TVFocusTile(
            title: '\u{2699}\u{FE0F}  ${AppStrings.settings}',
            dense: true,
            onPressed: onSettings ?? () {},
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}

class _RailItem {
  const _RailItem(this.name, this.count, this.emoji);
  final String name;
  final int count;
  final String emoji;
}
