import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/utils/focus_utils.dart';
import '../../../models/channel.dart';
import '../../../providers/epg_provider.dart';

class TvChannelCard extends StatelessWidget {
  const TvChannelCard({
    super.key,
    required this.channel,
    required this.onPressed,
    this.autofocus = false,
  });

  final Channel channel;
  final VoidCallback onPressed;
  final bool autofocus;

  @override
  Widget build(BuildContext context) {
    final epg = context.watch<EpgProvider>();
    final tvgId = channel.tvgId;
    final current = tvgId != null ? epg.getCurrentProgram(tvgId) : null;

    return FocusableItem(
      autofocus: autofocus,
      onPressed: onPressed,
      borderRadius: 14,
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Center(
                child: channel.logoUrl != null
                    ? CachedNetworkImage(
                        imageUrl: channel.logoUrl!,
                        fit: BoxFit.contain,
                        placeholder: (c, u) => const Icon(
                          Icons.live_tv_rounded,
                          color: AppColors.textDisabled,
                          size: 32,
                        ),
                        errorWidget: (c, u, e) => const Icon(
                          Icons.live_tv_rounded,
                          color: AppColors.textDisabled,
                          size: 32,
                        ),
                      )
                    : const Icon(
                        Icons.live_tv_rounded,
                        color: AppColors.accent,
                        size: 34,
                      ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              channel.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              current?.title ?? (channel.groupTitle ?? ''),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: AppColors.textSecondary,
                fontSize: 11,
              ),
            ),
            if (channel.isFavorite) ...[
              const SizedBox(height: 4),
              const Icon(Icons.star_rounded,
                  color: AppColors.warning, size: 14),
            ],
          ],
        ),
      ),
    );
  }
}
