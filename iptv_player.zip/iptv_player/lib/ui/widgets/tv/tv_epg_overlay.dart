import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_strings.dart';
import '../../../models/channel.dart';
import '../../../models/epg_program.dart';
import '../../../providers/epg_provider.dart';

class TvEpgOverlay extends StatelessWidget {
  const TvEpgOverlay({
    super.key,
    required this.channel,
    required this.onClose,
  });

  final Channel channel;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final epg = context.watch<EpgProvider>();
    final tvgId = channel.tvgId;
    final List<EpgProgram> programs = tvgId != null
        ? epg.getUpcomingPrograms(tvgId, count: 12)
        : <EpgProgram>[];
    final fmt = DateFormat('HH:mm');

    return Align(
      alignment: Alignment.centerRight,
      child: Container(
        width: 420,
        color: const Color(0xF00A0A0F),
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    AppStrings.epgGuide,
                    style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: onClose,
                  icon: const Icon(Icons.close_rounded,
                      color: AppColors.textSecondary),
                ),
              ],
            ),
            Text(
              channel.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                  color: AppColors.accentLight, fontSize: 14),
            ),
            const SizedBox(height: 14),
            if (epg.isLoading)
              const Padding(
                padding: EdgeInsets.only(top: 30),
                child: Center(
                  child: CircularProgressIndicator(
                    valueColor:
                        AlwaysStoppedAnimation<Color>(AppColors.accent),
                  ),
                ),
              )
            else if (programs.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 30),
                child: Text(
                  AppStrings.noEpgData,
                  style: TextStyle(
                      color: AppColors.textDisabled, fontSize: 14),
                ),
              )
            else
              Expanded(
                child: ListView.separated(
                  itemCount: programs.length,
                  separatorBuilder: (_, __) => const Divider(
                      color: AppColors.surfaceVariant, height: 14),
                  itemBuilder: (context, i) {
                    final p = programs[i];
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 54,
                          child: Text(
                            fmt.format(p.start),
                            style: TextStyle(
                              color: p.isLive
                                  ? AppColors.live
                                  : AppColors.textSecondary,
                              fontSize: 13,
                              fontWeight: p.isLive
                                  ? FontWeight.w700
                                  : FontWeight.w400,
                            ),
                          ),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                p.title,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: AppColors.textPrimary,
                                  fontSize: 14,
                                  fontWeight: p.isLive
                                      ? FontWeight.w700
                                      : FontWeight.w500,
                                ),
                              ),
                              if (p.description != null) ...[
                                const SizedBox(height: 3),
                                Text(
                                  p.description!,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      color: AppColors.textDisabled,
                                      fontSize: 12),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}
