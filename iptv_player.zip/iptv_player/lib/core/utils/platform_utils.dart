import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

class PlatformUtils {
  PlatformUtils._();

  /// Returns true if running on Android TV, Fire Stick, or Mi Box.
  /// Detected by checking if the device has leanback feature (no touchscreen).
  static bool _isTv = false;
  static bool _initialized = false;

  static const _channel = MethodChannel('iptv_player/platform');

  static Future<void> detectPlatform() async {
    if (_initialized) return;
    _initialized = true;

    if (kIsWeb) {
      _isTv = false;
      return;
    }

    if (Platform.isAndroid) {
      try {
        final bool result = await _channel.invokeMethod('isAndroidTV');
        _isTv = result;
      } catch (_) {
        // Fallback: assume mobile
        _isTv = false;
      }
    }
  }

  static bool get isTV => _isTv;
  static bool get isMobile => !_isTv;
  static bool get isAndroid => !kIsWeb && Platform.isAndroid;

  /// TV-optimized grid columns
  static int get tvGridColumns => 6;
  static int get mobileGridColumns => 2;

  /// Card sizes
  static double get tvCardWidth => 200.0;
  static double get tvCardHeight => 120.0;
  static double get mobileCardHeight => 72.0;

  /// Font scale for TV (larger for 10-foot UI)
  static double get tvFontScale => 1.2;
  static double get mobileFontScale => 1.0;
}
