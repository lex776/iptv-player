import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // Background
  static const Color background = Color(0xFF0A0A0F);
  static const Color surface = Color(0xFF12121A);
  static const Color surfaceVariant = Color(0xFF1C1C28);
  static const Color card = Color(0xFF1E1E2E);

  // Brand / Accent
  static const Color accent = Color(0xFF6C63FF);
  static const Color accentLight = Color(0xFF9D97FF);
  static const Color accentDark = Color(0xFF4A43CC);

  // TV Focus highlight - CRITICAL for D-Pad navigation visibility
  static const Color focusBorder = Color(0xFF6C63FF);
  static const Color focusBackground = Color(0xFF2D2B4E);
  static const Color focusShadow = Color(0x886C63FF);

  // Text
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFAAAAAA);
  static const Color textDisabled = Color(0xFF555566);

  // Status
  static const Color live = Color(0xFFFF4444);
  static const Color online = Color(0xFF44FF88);
  static const Color offline = Color(0xFF666666);
  static const Color warning = Color(0xFFFFAA00);

  // Gradient
  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF6C63FF), Color(0xFF3B36CC)],
  );

  static const LinearGradient cardGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Colors.transparent, Color(0xCC000000)],
  );

  static const LinearGradient sidebarGradient = LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: [Color(0xFF0A0A0F), Colors.transparent],
  );
}
