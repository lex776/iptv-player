class AppStrings {
  AppStrings._();

  static const String appName = 'IPTV Player';
  static const String loading = 'Loading...';
  static const String error = 'Error';
  static const String retry = 'Retry';
  static const String cancel = 'Cancel';
  static const String ok = 'OK';
  static const String save = 'Save';
  static const String delete = 'Delete';

  // Playlist
  static const String addPlaylist = 'Add Playlist';
  static const String playlistUrl = 'Playlist URL (M3U/M3U8)';
  static const String playlistName = 'Playlist Name';
  static const String loadPlaylist = 'Load Playlist';
  static const String loadFromFile = 'Load from File';
  static const String parseError = 'Failed to parse playlist';
  static const String networkError = 'Network error. Check your connection.';
  static const String noChannels = 'No channels found';
  static const String noPlaylists = 'No playlists added yet';

  // Categories
  static const String allChannels = 'All Channels';
  static const String favorites = 'Favorites';
  static const String recentlyWatched = 'Recently Watched';

  // Player
  static const String playerError = 'Failed to play stream';
  static const String aspectRatio = 'Aspect Ratio';
  static const String quality = 'Quality';
  static const String audioTrack = 'Audio Track';
  static const String subtitles = 'Subtitles';
  static const String channelList = 'Channels';

  // EPG
  static const String epgUrl = 'EPG URL (XMLTV)';
  static const String addEpg = 'Add EPG';
  static const String epgGuide = 'Program Guide';
  static const String noEpgData = 'No EPG data available';
  static const String now = 'Now';
  static const String next = 'Next';

  // Settings
  static const String settings = 'Settings';
  static const String managePlaylists = 'Manage Playlists';
  static const String epgSettings = 'EPG Settings';
  static const String playerSettings = 'Player Settings';
  static const String about = 'About';
}
