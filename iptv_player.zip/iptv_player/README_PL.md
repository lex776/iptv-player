# IPTV Player — jak zdobyć gotowy plik APK

Ten folder zawiera kompletny kod aplikacji IPTV (telefon + Android TV + Fire Stick).
APK zbuduje się **sam, darmowo, w chmurze GitHuba**. Nie musisz nic instalować na komputerze.
Czas: około 20 minut, z czego Twojej pracy 5 minut.

---

## KROK 1 — Rozpakuj ZIP

Kliknij prawym na pobrany plik `iptv_player.zip` → **Wyodrębnij wszystko**.
Powstanie folder `iptv_player`. Wejdź do niego. Musisz widzieć w środku:

```
.github        (folder)
lib            (folder)
tools          (folder)
pubspec.yaml   (plik)
.gitignore     (plik)
README_PL.md   (ten plik)
```

To jest ZAWARTOŚĆ, którą będziesz wgrywać. Ważne: wgrywasz **te elementy**, a nie
folder `iptv_player` w całości.

---

## KROK 2 — Konto GitHub (darmowe)

1. Wejdź na **github.com** → *Sign up*
2. Podaj e-mail, hasło, nazwę użytkownika, potwierdź e-mail

Jeśli masz już konto — po prostu się zaloguj.

---

## KROK 3 — Nowe repozytorium

1. W prawym górnym rogu kliknij **+** → **New repository**
2. *Repository name*: `iptv-player`
3. Zostaw **Public** (przy Private darmowe minuty budowania są ograniczone)
4. **Nie** zaznaczaj żadnych dodatków (README, .gitignore, licencja)
5. Kliknij **Create repository**

---

## KROK 4 — Wgraj pliki

1. Na stronie nowego repozytorium kliknij link **uploading an existing file**
   (jest w środku ekranu; alternatywnie: *Add file* → *Upload files*)
2. Otwórz Eksplorator Windows w folderze `iptv_player`
3. Zaznacz **wszystko** w środku (Ctrl+A) i przeciągnij na stronę GitHuba
4. Poczekaj, aż wszystkie pliki się wgrają (pojawi się lista)
5. Na dole kliknij zielony przycisk **Commit changes**

Sprawdź: na głównej stronie repozytorium musisz widzieć plik `pubspec.yaml`
oraz foldery `lib`, `tools`, `.github`. Jeśli widzisz zamiast tego jeden folder
`iptv_player` — wejdź w niego, usuń pliki i wgraj jeszcze raz samą zawartość.

---

## KROK 5 — Poczekaj na budowę

1. U góry repozytorium kliknij zakładkę **Actions**
2. Zobaczysz zadanie „Build IPTV Player APK" z żółtą kropką (trwa)
3. Odczekaj **15–25 minut**. Możesz zamknąć przeglądarkę i wrócić później
4. Gdy pojawi się zielony haczyk — gotowe

Jeśli zobaczysz czerwony krzyżyk: kliknij zadanie, potem czerwony krok,
skopiuj ostatnie 20 linii błędu i wyślij mi — poprawię.

---

## KROK 6 — Pobierz APK

**Sposób A (najprostszy):**
Wróć na główną stronę repozytorium → prawa kolumna **Releases** → kliknij
najnowszy wpis → pobierz plik **iptv-player.apk**

**Sposób B:**
Zakładka *Actions* → kliknij ukończone zadanie → sekcja *Artifacts* na dole →
`iptv-player-apk` (pobierze się ZIP, w środku jest APK)

---

## KROK 7 — Instalacja

### Telefon / tablet Android
1. Prześlij APK na telefon (kabel USB, Dysk Google, e-mail do siebie)
2. Otwórz plik w telefonie
3. Android zapyta o zgodę → **Ustawienia** → włącz *Zezwalaj z tego źródła* → wróć → **Instaluj**

### Android TV / Fire Stick
1. Na TV zainstaluj aplikację **Downloader** (jest w sklepie Amazon/Google)
2. Na Fire Stick włącz: *Ustawienia* → *My Fire TV* → *Developer options* → *Apps from Unknown Sources* = ON
3. W repozytorium GitHub skopiuj bezpośredni link do pliku APK z sekcji Releases
   (kliknij prawym na `iptv-player.apk` → *Kopiuj adres linku*)
4. W Downloaderze wpisz ten link → *Go* → *Install*

---

## Pierwsze uruchomienie

1. Aplikacja poprosi o dodanie playlisty
2. Wklej adres swojej playlisty M3U (albo wybierz plik `.m3u` z pamięci urządzenia)
3. Do testów możesz użyć darmowej, legalnej playlisty:
   `https://iptv-org.github.io/iptv/index.m3u`
4. Opcjonalnie dodaj adres EPG (XMLTV) — wtedy zobaczysz program telewizyjny

## Obsługa pilotem (Android TV / Fire Stick)

| Przycisk | Działanie |
|---|---|
| Góra / Dół | zmiana kanału |
| OK | pokaż / ukryj panel sterowania |
| Prawo | zmiana proporcji obrazu |
| Menu | program telewizyjny (EPG) |
| Wstecz | wyjście z odtwarzacza |

---

## Nowa wersja po zmianach

Każde wgranie zmienionego pliku na GitHub (*Add file* → *Upload files* → *Commit*)
automatycznie uruchamia budowę nowego APK. Stare wersje zostają w Releases.

---

## Alternatywa: budowa na własnym komputerze

Potrzebujesz Fluttera i Android Studio. W folderze projektu:

```
flutter create --platforms=android --org com.damian --project-name iptv_player C:\tmp\tpl
xcopy /E /I C:\tmp\tpl\android android
python tools\patch_android.py
flutter pub get
flutter build apk --release
```

Gotowy plik: `build\app\outputs\flutter-apk\app-release.apk`
